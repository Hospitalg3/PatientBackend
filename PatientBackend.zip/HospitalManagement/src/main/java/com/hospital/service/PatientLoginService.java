package com.hospital.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.PatientLoginRepository;
import com.hospital.model.PatientLogin;

@Service
public class PatientLoginService {

	@Autowired
	PatientLoginRepository patientloginRepository;

	public PatientLogin validatePatientLogin(PatientLogin patientlogin) {
		PatientLogin pl=patientloginRepository.validatePatientLogin(patientlogin.getP_id(),patientlogin.getP_password());
		
		return pl;
	}
	
}